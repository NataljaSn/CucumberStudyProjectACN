package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import pages_sample.MyAccountPage;

import java.util.List;

public class MyAccountPageSteps {
    private WebDriver driver;
    private MyAccountPage myAccountPage;

    public MyAccountPageSteps() {
        this.driver = Hooks.driver;
        myAccountPage = PageFactory.initElements(Hooks.driver, MyAccountPage.class);
    }

    //steps for US01
    @Then("User checks presence of link: {string}")
    public void user_checks_presence_of_link(String linkText) {
        String actualLinkText = myAccountPage.getEditYourAccountInfoLink().getText();
        Assert.assertEquals(linkText, actualLinkText);
    }

    @Given("User checks presence of blocks: {string}, {string}")
    public void user_checks_presence_of_blocks(String blockText1, String blockText2) {
        String actualBlockText1 = myAccountPage.getMyAccountBlock().getText();
        String actualBlockText2 = myAccountPage.getMyOrdersBlock().getText();
        Assert.assertEquals(blockText1, actualBlockText1);
        Assert.assertEquals(blockText2, actualBlockText2);
    }

    //steps for US02
    @Then("User checks that sub menu on the right side contains following sections")
    public void user_checks_that_sub_menu_on_the_right_side_contains_following_sections(List<String> list) {
        for (WebElement rightItem : myAccountPage.getRightSideLinks()) {
            Assert.assertTrue(list.contains(rightItem.getText()));
        }
    }

    @When("User checks that section My account on the left side of My Account page contains following links")
    public void user_checks_that_section_my_account_on_the_left_side_of_my_account_page_contains_following_links(List<String> list) {
        for (WebElement leftItem : myAccountPage.getLeftSideLinks()) {
            Assert.assertTrue(list.contains(leftItem.getText()));
        }
    }
}
