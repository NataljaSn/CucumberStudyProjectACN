package stepDefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import pages_sample.BasePage;
import pages_sample.RegisterAccountPage;

import java.util.Map;
import java.util.Random;

public class RegisterAccountPageSteps extends BasePage {
    private WebDriver driver;
    private RegisterAccountPage registerAccountPage;
    Random rand = new Random();
    int random = rand.nextInt(10000);

    public RegisterAccountPageSteps() {
        this.driver = Hooks.driver;
        registerAccountPage = PageFactory.initElements(Hooks.driver, RegisterAccountPage.class);
    }

    @Then("User fills in the fields with valid data")
    public void user_fills_in_the_fields_with_valid_data(DataTable userData) {
        for (Map<Object, Object> data : userData.asMaps(String.class, String.class)) {
            clearAndSendKeys(registerAccountPage.getFirstName(), (String) data.get("firstname"));
            clearAndSendKeys(registerAccountPage.getLastName(), (String) data.get("lastname"));
            clearAndSendKeys(registerAccountPage.getEmail(), random + (String) data.get("email"));
            clearAndSendKeys(registerAccountPage.getTelephone(), (String) data.get("telephone"));
            clearAndSendKeys(registerAccountPage.getPassword(), (String) data.get("password"));
            clearAndSendKeys(registerAccountPage.getPasswordConfirm(), (String) data.get("confirm"));
            registerAccountPage.getContinueBtn().click();
        }
    }

    @Then("User checks that in Newsletter block Subscribe No button is selected")
    public void user_checks_that_in_newsletter_block_Subscribe_No_button_is_selected() {
        registerAccountPage.getSubscribeButtonNo().click();
    }

    @Then("User checks Privacy Policy checkbox")
    public void user_checks_privacy_policy_checkbox() {
        registerAccountPage.getCheckBoxPrivacy().click();
    }

    @When("User clicks Continue button")
    public void user_clicks_continue_button() {
        registerAccountPage.getContinueBtn().click();
    }

    @Then("registration confirmation is visible: {string}")
    public void registration_confirmation_is_visible(String registerAccountConfirm) {
        String actualConfirmation =  registerAccountPage.getRegisterAccountMsg().getText();
        Assert.assertEquals(registerAccountConfirm, actualConfirmation);
    }

    @Then("privacy warning message is visible: {string}")
    public void privacy_warning_message_is_visible(String privacyWarningMsg) {
        String actualWarningMsg = registerAccountPage.getWarningPrivacyCheckbox().getText();
        Assert.assertEquals(privacyWarningMsg, actualWarningMsg);
    }

    @Then("warning message is visible: {string}")
    public void warning_message_is_visible(String warningMsg) {
        WebElement warning2 = driver.findElement(By.xpath("//*[text()='" + warningMsg + "']"));
        Assert.assertEquals(warningMsg, warning2.getText());
    }
}
