package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.java.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pages_sample.Homepage;

import static org.junit.Assert.assertEquals;

@Log
public class MainPageSteps {
    private WebDriver driver;
    private Homepage homepage;


    public MainPageSteps() {
        this.driver = Hooks.driver;
        homepage = PageFactory.initElements(Hooks.driver, Homepage.class);
    }

    @Given("^User is on the web-shop home page$")
    public void user_is_on_the_web_shop_home_page() {
        driver.get("http://www.demoshop24.com");
    }

    @Then("User sees web-shop home page name in the tab: {string}")
    public void user_sees_web_shop_home_page_name_in_the_tab(String tabName) {
        String actualTitle = driver.getTitle();
        assertEquals(tabName, actualTitle);
    }

    @Given("User clicks My Account link located in the page header;")
    public void user_clicks_my_account_link_located_in_the_page_header() {
        homepage.getMyAccountLink().click();
    }

    @When("User clicks Register link")
    public void user_clicks_register_link() {
        homepage.getRegisterLink().click();
    }

    //Step definitions for QESDEMO-278 & 280:
    @Given("User clicks Login link")
    public void user_clicks_login_link() {
        homepage.getLoginLink().click();
    }

    @When("User clicks add to cart button under the product located on the homepage under Featured block: {string}")
    public void user_clicks_add_to_cart_button_under_the_product_located_on_the_homepage_under_featured_block(String chosenProduct) {
        int listItemNumber = 0;
        for (int i = 0; i < homepage.getProductList().size(); i++) {
            if (homepage.getProductList().get(i).getText().equals(chosenProduct)) {
                listItemNumber = i;
                break;
            }
        }
        log.info("test" + listItemNumber);

        homepage.getAddToCartButtons().get(listItemNumber + 2).click();
        //+2 necessary as button list contains 6 items, but product list - 4 items
    }

    @Given("User clicks checkout button in the upper right corner")
    public void user_clicks_checkout_button_in_the_upper_right_corner() {
        homepage.getCheckoutArrowBtn().click();
    }
}

