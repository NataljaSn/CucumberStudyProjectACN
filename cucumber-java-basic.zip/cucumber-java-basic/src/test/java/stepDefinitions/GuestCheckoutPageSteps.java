package stepDefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pages_sample.BasePage;
import pages_sample.CheckoutPage;
import pages_sample.GuestCheckoutPage;

import java.util.List;
import java.util.Map;

public class GuestCheckoutPageSteps extends BasePage {
    private WebDriver driver;
    private GuestCheckoutPage guestCheckoutPage;
    private CheckoutPage checkoutPage;

    public GuestCheckoutPageSteps() {
        this.driver = Hooks.driver;
        guestCheckoutPage = PageFactory.initElements(Hooks.driver, GuestCheckoutPage.class);
        checkoutPage = PageFactory.initElements(Hooks.driver, CheckoutPage.class);
    }

    @Then("user checks presence of Guest checkout radio button in New Customer frame")
    public void user_checks_presence_of_radio_button_in_new_customer_frame() {
        waitUntilIsClickable(guestCheckoutPage.getGuestCheckoutRadioBtn());
        Assert.assertTrue(guestCheckoutPage.getGuestCheckoutRadioBtn().isDisplayed());
    }

    @When("User clicks Guest checkout radio button")
    public void user_clicks_guest_checkout_radio_button() {
        waitUntilVisibilityOf(guestCheckoutPage.getGuestCheckoutRadioBtn());
        guestCheckoutPage.getGuestCheckoutRadioBtn().click();
    }

    @Then("User clicks Continue button in Step1 New Customer frame")
    public void user_clicks_continue_button_in_step1_new_customer_frame() {
        guestCheckoutPage.getContinueStep1Btn().click();
    }

    @Then("user fills in valid billing data")
    public void user_fills_in_valid_billing_data(DataTable userData) {
        for (Map<Object, Object> data : userData.asMaps(String.class, String.class)) {
            clearAndSendKeys(guestCheckoutPage.getFirstName(), (String) data.get("firstname"));
            clearAndSendKeys(guestCheckoutPage.getLastName(), (String) data.get("lastname"));
            clearAndSendKeys(guestCheckoutPage.getEmail(), (String) data.get("email"));
            clearAndSendKeys(guestCheckoutPage.getTelephone(), (String) data.get("telephone"));
            clearAndSendKeys(guestCheckoutPage.getCompany(), (String) data.get("company"));
            clearAndSendKeys(guestCheckoutPage.getAddress1(), (String) data.get("address1"));
            clearAndSendKeys(guestCheckoutPage.getAddress2(), (String) data.get("address2"));
            clearAndSendKeys(guestCheckoutPage.getCity(), (String) data.get("city"));
            clearAndSendKeys(guestCheckoutPage.getPostcode(), (String) data.get("postCode"));
        }
    }

    @Then("User selects from drop-down menus Country and Region")
    public void user_selects_from_drop_down_menus_country_and_region(DataTable location) {
        List<Map<String, String>> data = location.asMaps(String.class, String.class);
        selectFromDropdown(guestCheckoutPage.getCountry(), data.get(0).get("country"));
        selectFromDropdown(guestCheckoutPage.getRegion(), data.get(0).get("region"));
    }

    @When("User clicks Continue button in Step2")
    public void user_clicks_continue_button_in_step2() {
        guestCheckoutPage.getContinueStep2Btn().click();
    }

    @Then("User fills in some fields with invalid data")
    public void user_fills_in_some_fields_with_invalid_data(DataTable userData) {
        for (Map<Object, Object> data : userData.asMaps(String.class, String.class)) {
            clearAndSendKeys(guestCheckoutPage.getFirstName(), (String) data.get("firstname"));
            clearAndSendKeys(guestCheckoutPage.getLastName(), (String) data.get("lastname"));
            clearAndSendKeys(guestCheckoutPage.getEmail(), (String) data.get("email"));
            clearAndSendKeys(guestCheckoutPage.getTelephone(), (String) data.get("telephone"));
            clearAndSendKeys(guestCheckoutPage.getAddress1(), (String) data.get("address1"));
            clearAndSendKeys(guestCheckoutPage.getCity(), (String) data.get("city"));
        }
    }

    @Given("User checks the box My delivery and billing addresses are the same")
    public void user_checks_the_box_my_delivery_and_billing_addresses_are_the_same() {
        if (guestCheckoutPage.getCheckboxMyDeliveryAndBilling().isSelected()) {
            Assert.assertTrue(guestCheckoutPage.getCheckboxMyDeliveryAndBilling().isSelected());
        } else {
            guestCheckoutPage.getCheckboxMyDeliveryAndBilling().click();
        }
    }

    // steps for   QESDEMO-281
    @Then("User checks presence of required fields")
    public void user_checks_presence_of_required_fields(List<String> list) {
        for (String requiredField : list) {
            Assert.assertTrue(resolveElementInFieldBlockByName(guestCheckoutPage.getRequiredPersDetailsBlockInStep2(), requiredField).isDisplayed());
        }
    }

    @Then("User checks presence of required Address fields")
    public void user_checks_presence_of_required_address_fields(List<String> list) {
        for (String requiredField : list) {
            Assert.assertTrue(resolveElementInFieldBlockByName(guestCheckoutPage.getRequiredAddressBlockInStep2(), requiredField).isDisplayed());
        }
    }

    @Then("User checks presence of checkbox My delivery and billing addresses are the same")
    public void user_checks_presence_of_checkbox_my_delivery_and_billing_addresses_are_the_same() {
        Assert.assertTrue(guestCheckoutPage.getCheckboxMyDeliveryAndBilling().isSelected());
    }
}

