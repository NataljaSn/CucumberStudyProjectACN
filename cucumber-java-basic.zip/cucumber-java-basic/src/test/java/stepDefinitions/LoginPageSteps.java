package stepDefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pages_sample.BasePage;
import pages_sample.LoginPage;

import java.util.List;
import java.util.Map;


public class LoginPageSteps extends BasePage {

    private WebDriver driver;
    private LoginPage loginPage;

    public LoginPageSteps() {
        this.driver = Hooks.driver;
        loginPage = PageFactory.initElements(Hooks.driver, LoginPage.class);
    }

    @When("User enters valid credentials")
    public void user_enters_valid_credentials(DataTable loginCredentials) {
        List<Map<String, String>> data = loginCredentials.asMaps(String.class, String.class);
        clearAndSendKeys(loginPage.getEmailToLogin(), data.get(0).get("email"));
        clearAndSendKeys(loginPage.getPasswordToLogin(), data.get(0).get("password"));
    }

    @When("User clicks Login button")
    public void user_clicks_login_button() {
        loginPage.getLoginBtn().click();
    }

    @Then("red warning message is visible: {string}")
    public void red_warning_message_is_visible(String warningMsg) {
        String actualWarningMsg = loginPage.getWarningMsgLogin().getText();
        Assert.assertEquals(warningMsg, actualWarningMsg);
    }
}
