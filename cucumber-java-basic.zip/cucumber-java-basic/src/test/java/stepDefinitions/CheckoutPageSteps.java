package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages_sample.BasePage;
import pages_sample.CheckoutPage;
import pages_sample.CheckoutPaymentMethodPage;

public class CheckoutPageSteps extends BasePage {
    private WebDriver driver;
    private CheckoutPage checkoutPage;
    private CheckoutPaymentMethodPage checkoutPaymentMethodPage;

    public CheckoutPageSteps() {
        this.driver = Hooks.driver;
        checkoutPage = PageFactory.initElements(Hooks.driver, CheckoutPage.class);
        checkoutPaymentMethodPage = PageFactory.initElements(Hooks.driver, CheckoutPaymentMethodPage.class);
    }

    @Then("User checks the box I have read and agree to the Terms & Conditions")
    public void user_checks_the_box_i_have_read_and_agree_to_the_terms_conditions() {
        waitUntilIsClickable(checkoutPaymentMethodPage.getCheckboxTerms());
        checkoutPaymentMethodPage.getCheckboxTerms().click();
    }

    @When("User clicks Continue button in PaymentMethod block")
    public void user_clicks_continue_button_in_PaymentMethod_block() {
        checkoutPaymentMethodPage.getContinuePaymentMethodBtn().click();
    }

    @Given("User clicks Continue button in Step4 Delivery Method block")
    public void user_clicks_continue_button_in_step4_delivery_method_block() {
        checkoutPage.getContinueStep4Btn().click();
    }

    @Given("User clicks Confirm Order button in Step6 Confirm Order block")
    public void user_clicks_confirm_order_button_in_step6_confirm_order_block() {
        checkoutPage.getConfirmOrderBtn().click();
    }

    @Then("Order is placed and message appears: {string}")
    public void order_is_placed_and_message_appears(String orderConfirmMsg) {
        waitUntilVisibilityOf(checkoutPage.getSuccessLabel());
        String actualConfirmMsg =checkoutPage.getConfirmOrderMsg().getText();
        Assert.assertEquals(orderConfirmMsg, actualConfirmMsg);
    }

    @Then("Step 3 warning message is visible: {string}")
    public void step_3_warning_message_is_visible(String warningMsg) {
        waitUntilVisibilityOf(checkoutPaymentMethodPage.getNoPaymentMethodMsg());
        String actualWarningMsg =  checkoutPaymentMethodPage.getNoPaymentMethodMsg().getText();
        Assert.assertEquals(warningMsg,actualWarningMsg);
    }

    @Then("warning message is present: {string}")
    public void warning_message_is_present(String warningMsg) {
        WebElement actualWarningMsg = checkoutPaymentMethodPage.getPaymentMethodRequiredMsg();
        waitUntilTextPresent(actualWarningMsg, warningMsg);
        Assert.assertEquals(warningMsg, actualWarningMsg.getText().substring(0, 33));
        Assert.assertTrue(warningMsg, actualWarningMsg.isDisplayed());
    }
}
