package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

@Getter
public class RegisterAccountPage {
    @FindBy(how = How.ID, using = "input-firstname")
    private WebElement firstName;
    @FindBy(how = How.ID, using = "input-lastname")
    private WebElement lastName;
    @FindBy(how = How.ID, using = "input-email")
    private WebElement email;
    @FindBy(how = How.ID, using = "input-telephone")
    private WebElement telephone;
    @FindBy(how = How.ID, using = "input-password")
    private WebElement password;
    @FindBy(how = How.ID, using = "input-confirm")
    private WebElement passwordConfirm;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")
    private WebElement subscribeButtonNo;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/form/div/div/input[1]")
    private WebElement checkBoxPrivacy;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/form/div/div/input[2]")
    private WebElement continueBtn;

    @FindBy(how = How.XPATH, using = "//*[@id='content']/h1")
    private WebElement registerAccountMsg;

    //Warning messages for invalid input:
    @FindBy(how = How.XPATH, using = "//*[@id='account']/div[2]/div/div")
    private WebElement warningFirstName;
    @FindBy(how = How.XPATH, using = "//*[@id='account']/div[4]/div/div")
    private WebElement warningEmail;
    @FindBy(how = How.XPATH, using = "//*[@id='account']/div[5]/div/div")
    private WebElement warningTelephone;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/form/fieldset[2]/div[2]/div/div")
    private WebElement warningPasswordConfirm;
    @FindBy(how = How.XPATH, using = "//*[@id='account-register']/div[1]")
    private WebElement warningPrivacyCheckbox;

}
