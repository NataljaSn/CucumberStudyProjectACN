package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import stepDefinitions.Hooks;

@Getter
public class CheckoutPaymentMethodPage {
    private WebDriver driver;

    public CheckoutPaymentMethodPage() {
        this.driver = Hooks.driver;
    }

    @FindBy(how = How.ID, using = "button-payment-method")
    private WebElement continuePaymentMethodBtn;
    @FindBy(how = How.CSS, using = "div>input[type=checkbox]")
    private WebElement checkboxTerms;
    @FindBy(how = How.CSS, using = "div.alert.alert-warning.alert-dismissible")
    private WebElement noPaymentMethodMsg;
    @FindBy(how = How.CSS, using = "div.alert.alert-danger.alert-dismissible")
    private WebElement paymentMethodRequiredMsg;

}
