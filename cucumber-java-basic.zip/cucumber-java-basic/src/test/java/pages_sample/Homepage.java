package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

@Getter
public class Homepage {
    @FindBy(how = How.CSS, using = "ul.list-inline>li:nth-child(2)")
    private WebElement myAccountLink;
    @FindBy(how = How.CSS, using = "li.dropdown.open>ul>li:first-child")
    private WebElement registerLink;
    @FindBy(how = How.CSS, using = "li.dropdown.open>ul>li:last-child")
    private WebElement loginLink;

    @FindBy(how = How.XPATH, using = "//*[contains(@class, 'fa fa-shopping-cart')]")
    private List<WebElement> addToCartButtons;

    @FindBy(how = How.CSS, using = "h4")
    private List<WebElement> productList;

    @FindBy(how = How.CSS, using = "ul.list-inline>li:last-child")
    private WebElement checkoutArrowBtn;

}
