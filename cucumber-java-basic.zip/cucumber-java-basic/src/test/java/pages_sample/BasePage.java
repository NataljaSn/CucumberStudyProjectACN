package pages_sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepDefinitions.Hooks;

public class BasePage {
    private WebDriver driver;

    public BasePage() {
        this.driver = Hooks.driver;
    }
//Field filling
    public void clearAndSendKeys(WebElement webelement, String string){
        webelement.clear();
        webelement.sendKeys(string);
    }

    public void selectFromDropdown(WebElement webelement, String string) {
        Select obj = new Select(webelement);
        obj.selectByVisibleText(string);
    }
// resolving element from block of elements
    public WebElement resolveElementInFieldBlockByName(WebElement elementBlock, String elementName){
       return elementBlock.findElement(By.name(elementName));
    }

    public WebElement resolveElementByID(WebElement generalElement, String elementName){
        return generalElement.findElement(By.id(elementName));
    }
//Waits
    public void waitUntilVisibilityOf(WebElement webElement){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(webElement));
    }

    public void waitUntilTextPresent(WebElement webElement, String string){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.textToBePresentInElement(webElement, string));
    }
    public void waitUntilIsClickable(WebElement webElement) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.elementToBeClickable(webElement));
    }
}
