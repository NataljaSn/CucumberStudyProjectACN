package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import stepDefinitions.Hooks;

@Getter
public class CheckoutPage {
    private WebDriver driver;

    public CheckoutPage() {
        this.driver = Hooks.driver;
     }

    //Step 4 Delivery Method input fields
    @FindBy(how = How.ID, using = "button-shipping-method")
    private WebElement continueStep4Btn;

    //Step 6 Confirm Order input fields
    @FindBy(how = How.ID, using = "button-confirm")
    private WebElement confirmOrderBtn;

    //Step Order approval page
    @FindBy(how = How.CSS, using = "#content>h1")
    private WebElement confirmOrderMsg;
    @FindBy(how = How.CSS, using = "#common-success>ul>li:last-child")
    private WebElement successLabel;

}
