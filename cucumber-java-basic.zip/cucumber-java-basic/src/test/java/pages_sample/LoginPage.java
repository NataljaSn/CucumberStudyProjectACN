package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

@Getter
public class LoginPage {
    //Objects on My Account/Login page
    @FindBy(how = How.ID, using = "input-email")
    private WebElement emailToLogin;

    @FindBy(how = How.ID, using = "input-password")
    private WebElement passwordToLogin;

    @FindBy(how = How.CSS, using = "[value=Login]")
    private WebElement loginBtn;

    @FindBy(how = How.CSS, using = "#account-login>div.alert")
    private WebElement warningMsgLogin;
}
