package pages_sample;

import lombok.Getter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import stepDefinitions.Hooks;

import java.util.List;

@Getter
public class GuestCheckoutPage {
    private WebDriver driver;

    public GuestCheckoutPage() {
        this.driver = Hooks.driver;
    }

    //Step 1 input fields
    @FindBy(how = How.CSS, using = "[value='guest']")
    private WebElement guestCheckoutRadioBtn;
    @FindBy(how = How.XPATH, using = "//*[@id='button-account']")
    private WebElement continueStep1Btn;

    //Step 2 input fields
    @FindBy(how = How.XPATH, using = "//*[@id='button-guest']")
    private WebElement continueStep2Btn;
    @FindBy(how = How.ID, using = "input-payment-firstname")
    private WebElement firstName;
    @FindBy(how = How.ID, using = "input-payment-lastname")
    private WebElement lastName;
    @FindBy(how = How.ID, using = "input-payment-email")
    private WebElement email;
    @FindBy(how = How.ID, using = "input-payment-telephone")
    private WebElement telephone;
    @FindBy(how = How.ID, using = "input-payment-company")
    private WebElement company;
    @FindBy(how = How.ID, using = "input-payment-address-1")
    private WebElement address1;
    @FindBy(how = How.ID, using = "input-payment-address-2")
    private WebElement address2;
    @FindBy(how = How.ID, using = "input-payment-city")
    private WebElement city;
    @FindBy(how = How.ID, using = "input-payment-postcode")
    private WebElement postcode;
    @FindBy(how = How.ID, using = "input-payment-country")
    private WebElement country;
    @FindBy(how = How.ID, using = "input-payment-zone")
    private WebElement region;
    @FindBy(how = How.NAME, using = "shipping_address")
    private WebElement checkboxMyDeliveryAndBilling;
    @FindBy(how = How.CSS, using = ".form-group.required")
    private List<WebElement> requiredFieldsInStep2;

    @FindBy(how = How.CSS, using = "fieldset#account")
    private WebElement requiredPersDetailsBlockInStep2;

    @FindBy(how = How.CSS, using = "fieldset#address")
    private WebElement requiredAddressBlockInStep2;
}

