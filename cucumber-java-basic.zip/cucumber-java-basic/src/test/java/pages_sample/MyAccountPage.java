package pages_sample;

import lombok.Getter;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

@Getter
public class MyAccountPage {

    //Objects visible in My Account when user is logged in
    @FindBy(how = How.XPATH, using = "//*[@id='content']/ul[1]/li[1]/a")
    private WebElement editYourAccountInfoLink;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/h2[1]")
    private WebElement myAccountBlock;
    @FindBy(how = How.XPATH, using = "//*[@id='content']/h2[2]")
    private WebElement myOrdersBlock;

    //Objects used in US02
    @FindBy(how = How.CSS, using = "#content>ul.list-unstyled>li>a")
    private List<WebElement> leftSideLinks;
    @FindBy(how = How.CSS, using = "a.list-group-item")
    private List<WebElement> rightSideLinks;
}
