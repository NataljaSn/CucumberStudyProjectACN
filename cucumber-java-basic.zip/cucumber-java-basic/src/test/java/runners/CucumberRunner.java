package runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features/",
        plugin = {"pretty", "html:cucumber-report/html-report",
                "junit:cucumber-report/junit-report.xml",
                "json:cucumber-report/json-report.json"},
//        tags = "@Sample2",
        tags = "@SampleUS01",
        dryRun = true, //checks if there are step definitions. dryRun = true <<will scan all the Gherkins, won't run anything
        // if some don't have - it will create - u can copy prepared methods
        glue = {"stepDefinitions"}
)
public class CucumberRunner {
}
