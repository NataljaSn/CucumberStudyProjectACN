
![Alt text](img/git_new_branch_1.png?raw=true "git new branch 1 via IDEA")
![Alt text](img/git_new_branch_2.png?raw=true "git new branch 2 via IDEA")
![Alt text](img/git_new_branch_3.png?raw=true "git new branch 3 via IDEA")

Note: replace branch_name with your name and surname (NO SPACES)