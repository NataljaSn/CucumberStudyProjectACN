### How to add, commit and push changes to
Open git bash from project folder (new_project) and do:
![Alt text](img/git_add.png?raw=true "git add via IDEA")
![Alt text](img/git_commit_1.png?raw=true "git commit 1 via IDEA")
![Alt text](img/git_commit_2.png?raw=true "git commit 2 via IDEA")
![Alt text](img/git_commit_3.png?raw=true "git commit 3 via IDEA")
![Alt text](img/git_push_1.png?raw=true "git push 1 via IDEA")
![Alt text](img/git_push_2.png?raw=true "git push 2 via IDEA")

Note: replace branch_name with your name and surname (NO SPACES)